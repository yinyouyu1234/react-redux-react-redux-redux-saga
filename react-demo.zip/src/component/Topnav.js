import React from 'react'

class Topnav extends React.Component {
  render() {
    return (
      <div>
        <div>顶部导航</div>
      </div>
    )
  }
}
export default Topnav